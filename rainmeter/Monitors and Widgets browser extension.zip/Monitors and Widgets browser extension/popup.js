// Monitors and Widgets (test 344): the extension's window. What it shows comes from the extension's storage, which
// the background keeps (sw.js): connected to the skin's helper or not, the Photo card's Browser button (cardOn), the
// switch here (enabled) and the Menu's colours (look: sent by the helper). It follows them as they change.
const $ = (id) => document.getElementById(id);
const root = document.documentElement.style;

function rgb(s, a) {
  const c = String(s || '').split(',').map((x) => Number(x.trim()));
  if (c.length < 3 || c.some((x) => Number.isNaN(x))) return null;
  return a === undefined ? `rgb(${c[0]}, ${c[1]}, ${c[2]})` : `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${a})`;
}

// the Menu's colours: its accent, the ink on it, a dark or a light window
function colours(look) {
  if (!look) return;
  const dark = look.dark !== false;
  root.setProperty('--base', dark ? '#1d1d20' : '#f3f3f6');
  root.setProperty('--label', dark ? '#ffffff' : '#000000');
  root.setProperty('--label2', dark ? 'rgba(235, 235, 245, 0.64)' : 'rgba(60, 60, 67, 0.64)');
  root.setProperty('--label3', dark ? 'rgba(235, 235, 245, 0.30)' : 'rgba(60, 60, 67, 0.30)');
  root.setProperty('--panel', dark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.04)');
  root.setProperty('--edge', dark ? 'rgba(255, 255, 255, 0.10)' : 'rgba(0, 0, 0, 0.08)');
  root.setProperty('--track', dark ? 'rgba(255, 255, 255, 0.16)' : 'rgba(0, 0, 0, 0.12)');
  if (rgb(look.accent)) {
    root.setProperty('--accent', rgb(look.accent));
    root.setProperty('--accent-soft', rgb(look.accent, 0.22));
  }
  if (rgb(look.ink)) root.setProperty('--ink', rgb(look.ink));
}

function show(r) {
  colours(r.look);
  const enabled = r.enabled !== false;
  $('on').setAttribute('aria-checked', String(enabled));
  let title, small, on = false;
  if (!r.connected) {
    title = 'Not connected';
    small = 'Rainmeter isn’t running, or Monitors and Widgets isn’t installed on this PC.';
  } else if (!r.cardOn) {
    title = 'The card’s Browser button is off';
    small = 'Videos stay in the browser. Turn it on under the Photo card’s clock.';
  } else if (!enabled) {
    title = 'Turned off here';
    small = 'Videos stay in the browser until you turn it on below.';
  } else {
    on = true;
    title = 'Videos go to the card';
    small = 'Play a video with a click and it opens in the Photo card.';
  }
  $('state').classList.toggle('on', on);
  $('title').textContent = title;
  $('small').textContent = small;
  if (document.body.classList.contains('wait')) requestAnimationFrame(() => document.body.classList.remove('wait'));
}

function read() {
  chrome.storage.local.get({ enabled: true, cardOn: false, connected: false, look: null }, show);
}

$('on').addEventListener('click', () => {
  chrome.storage.local.get({ enabled: true }, (r) => chrome.storage.local.set({ enabled: !(r.enabled !== false) }));
});
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local') read(); });
$('foot').textContent = 'Extension ' + chrome.runtime.getManifest().version;
// (the background may sleep with no connection: woken, it connects)
chrome.runtime.sendMessage({ wake: 1 }, () => void chrome.runtime.lastError);
read();
