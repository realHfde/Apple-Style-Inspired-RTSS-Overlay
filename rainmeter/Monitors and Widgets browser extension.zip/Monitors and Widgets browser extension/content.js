// Monitors and Widgets (tests 137-141): in every page. While the extension is on (its icon) and the Photo card's
// Browser button is on, a video you start (a click or a key: a browser allows picture-in-picture only then) goes into
// picture-in-picture, and the skin puts that window into the card. Both switches are kept in the extension's storage
// and read here as they change: nothing is asked when a video plays.
// (Test 141)
//  * A video starts before it knows its size (YouTube, a new video): it goes once it does, while the click counts.
//  * Turned off (the icon, or another button under the clock): the video comes back to its page and plays on.
//  * Turned on while a video plays: the next click or key on the page takes it into the card.
//  * Small videos and muted ones (previews under the mouse) are left.
//  * After an update this copy is put into the pages already open; an older copy left in them can no longer start
//    picture-in-picture (it asks through the page's video, which now says no), and a copy whose extension was
//    reloaded stops.
// (Test 356, 2.1)
//  * It says what it is doing, each time that changes (the card shows it while it waits): "waiting for a click", "in
//    the card", "can't leave its page: <why>" (muted, too small, the site does not allow it), "no video playing".
//    (356c) A page whose video plays says it in sight or not (his 356 run: Brave minimised, its page was "hidden", said
//    nothing, and the card never pressed the shortcut); "no video playing" only from a page in sight (a tab in the
//    background does not speak over the one he looks at).
//  * It tells when its video enters or leaves picture-in-picture (the card's log then knows it went back to its page).
//  * window.__mwGo: the video playing goes into the card (the extension's shortcut calls it: an experiment).
(() => {
  const V = 5;
  if ((window.__mwVideosV || 0) >= V) return;
  window.__mwVideosV = V;
  window.__mwVideos = true;
  document.documentElement.dataset.mwVideos = String(V);
  const request = HTMLVideoElement.prototype.__mwRequest || HTMLVideoElement.prototype.requestPictureInPicture;
  HTMLVideoElement.prototype.__mwRequest = request;
  // (older copies call this one: they stay quiet)
  HTMLVideoElement.prototype.requestPictureInPicture = function () {
    return Promise.reject(new DOMException('an older copy of Monitors and Widgets', 'NotAllowedError'));
  };

  let enabled = true;
  let cardOn = false;
  let armed = false;
  const noted = new WeakSet();

  function alive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  function tell(m) {
    if (!alive()) return;
    try {
      chrome.runtime.sendMessage(m, () => void chrome.runtime.lastError);
    } catch (e) { /* (the extension was reloaded) */ }
  }

  function on() {
    return enabled && cardOn && alive();
  }

  // (test 356) what it is doing, said once each time it changes; (356c) about a video that plays (playing: true) in
  // sight or not, else by a page in sight only
  let said = '';
  function say(text, playing) {
    if (!on() || (!playing && document.visibilityState !== 'visible') || text === said) return;
    said = text;
    tell({ says: text });
  }

  // why a video playing can't leave its page (none: it can; '': a preview, said nothing of)
  function cannot(v) {
    if (v.closest('ytd-video-preview, #video-preview, #inline-preview-player')) return '';
    if (v.disablePictureInPicture || !document.pictureInPictureEnabled) return 'the site does not allow it';
    if (v.muted) return 'it is muted';
    const r = v.getBoundingClientRect();
    if (r.width < 320 || r.height < 180) return 'it is too small';
    return null;
  }

  function fits(v) {
    if (!(v instanceof HTMLVideoElement) || v.muted || v.disablePictureInPicture) return false;
    if (v.closest('ytd-video-preview, #video-preview, #inline-preview-player')) return false;
    const r = v.getBoundingClientRect();
    return r.width >= 320 && r.height >= 180;
  }

  function clicked() {
    return !!(navigator.userActivation && navigator.userActivation.isActive);
  }

  function go(v) {
    if (!on() || document.pictureInPictureElement === v) return;
    request.call(v).catch((err) => {
      tell({ failed: String(err && err.name) + ': ' + String(err && err.message) +
        (clicked() ? '' : ' (the click no longer counted)') + ' on ' + location.hostname });
      // (test 356, C3) the browser's five seconds were over: the next click takes it; any other refusal: why
      if (err && err.name === 'NotAllowedError' && !clicked()) {
        arm();
        say('waiting for a click', true);
      } else {
        say("can't leave its page: " + String(err && err.message || err), true);
      }
    });
  }

  // a video that starts: now, or as soon as it knows its size; with no click: the next click or key
  function start(v) {
    if (!on() || document.pictureInPictureElement === v || !(v instanceof HTMLVideoElement)) return;
    // (test 356, C14) a video that can't leave its page: why, said
    const why = cannot(v);
    if (why) { if (!playing()) say("can't leave its page: " + why, true); return; }
    if (why === '' || !fits(v)) return;
    if (!clicked()) {
      if (!noted.has(v)) {
        noted.add(v);
        tell({ note: 'a video started with no click or key: the next click or key on the page takes it into the card' });
      }
      arm();
      say('waiting for a click', true);      // (test 356, C2)
      return;
    }
    if (v.readyState >= 1) {
      go(v);
      return;
    }
    v.addEventListener('loadedmetadata', () => {
      if (clicked()) go(v);
      else arm();
    }, { once: true });
  }

  // the biggest video playing on the page
  function playing() {
    let best = null;
    let size = 0;
    for (const v of document.querySelectorAll('video')) {
      if (v.paused || v.ended || !fits(v)) continue;
      const r = v.getBoundingClientRect();
      if (r.width * r.height > size) {
        size = r.width * r.height;
        best = v;
      }
    }
    return best;
  }

  // the next click or key takes the video playing into the card; a click on the video itself does nothing else
  // (it would pause it)
  function arm() {
    if (armed || window !== window.top && !document.querySelector('video')) return;
    armed = true;
    const swallow = (e) => {
      e.stopImmediatePropagation();
      e.preventDefault();
    };
    const fire = (e) => {
      if (!e.isTrusted) return;
      // (a box to type in is left alone, clicked or typed in; Escape gives no click that counts)
      const t = e.target;
      if ((e.type === 'keydown' && e.key === 'Escape') || (t instanceof HTMLElement &&
          (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)))) return;
      disarm();
      const v = playing();
      if (!v || !on() || document.pictureInPictureElement) return;
      if (e.type === 'pointerdown') {
        const r = v.getBoundingClientRect();
        if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
          for (const t of ['pointerup', 'mouseup', 'click']) window.addEventListener(t, swallow, { capture: true, once: true });
          swallow(e);
        }
      } else {
        swallow(e);
      }
      go(v);
    };
    const disarm = () => {
      armed = false;
      window.removeEventListener('pointerdown', fire, true);
      window.removeEventListener('keydown', fire, true);
    };
    window.addEventListener('pointerdown', fire, true);
    window.addEventListener('keydown', fire, true);
    arm.disarm = disarm;
  }

  // turned off: the video in picture-in-picture comes back to its page (it plays on); turned on: one playing goes
  function changed(was) {
    const now = on();
    if (was && !now) {
      said = '';
      if (arm.disarm) arm.disarm();
      if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
    } else if (!was && now) {
      // (test 356, C1) on while a video plays: it waits for a click, and says so (before: silently)
      if (document.pictureInPictureElement) say('in the card', true);
      else if (playing()) { arm(); say('waiting for a click', true); }
      else report();
    }
  }

  // (test 356) nothing to take: a video playing that can't leave its page (why), or none at all (the top page only)
  function report() {
    for (const v of document.querySelectorAll('video')) {
      if (v.paused || v.ended) continue;
      const why = cannot(v);
      if (why) { say("can't leave its page: " + why, true); return; }
    }
    if (window === window.top) say('no video playing');
  }

  // (test 356, 15C: an experiment) the extension's shortcut: the video playing goes into the card now
  window.__mwGo = () => {
    if (!on() || document.pictureInPictureElement) return;
    const v = playing();
    if (v) go(v);
    else report();
  };

  try {
    chrome.storage.local.get({ enabled: true, cardOn: false }, (r) => {
      const was = on();
      enabled = r.enabled !== false;
      cardOn = !!r.cardOn;
      changed(was);
    });
    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== 'local' || !(c.enabled || c.cardOn)) return;
      const was = on();
      if (c.enabled) enabled = c.enabled.newValue !== false;
      if (c.cardOn) cardOn = !!c.cardOn.newValue;
      changed(was);
    });
    // (the background wakes and connects, if it slept with no connection)
    if (window === window.top) chrome.runtime.sendMessage({ wake: 1 }, () => void chrome.runtime.lastError);
  } catch (e) { /* (the extension was reloaded) */ }

  document.addEventListener('play', (e) => start(e.target), true);
  // (an older copy left in the page by an update, in a world of its own, may still start picture-in-picture: while
  // this one says off, it is undone at once)
  document.addEventListener('enterpictureinpicture', () => {
    if (alive() && !on()) { document.exitPictureInPicture().catch(() => {}); return; }
    tell({ note: 'entered picture-in-picture' });      // (test 356, B3)
    said = '';
    say('in the card', true);
  }, true);
  // (test 356, B3) the card's log then knows the video went back to its page
  document.addEventListener('leavepictureinpicture', () => {
    tell({ note: 'left picture-in-picture' });
    said = '';
  }, true);
  // (a page that comes into sight says what it is doing, once)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible' || !on() || said) return;
    if (document.pictureInPictureElement) say('in the card');
    else if (playing()) { arm(); say('waiting for a click'); }
  });
})();
