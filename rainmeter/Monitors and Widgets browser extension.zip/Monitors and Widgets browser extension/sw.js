// Monitors and Widgets (tests 137-141, 344): the extension's background. It keeps one connection to the skin's helper
// (Scripts\Cache\MWHost-<tag>.exe, the native messaging host "com.monitorsandwidgets.media"), which says at once and
// whenever it changes whether the Photo card's Browser button is on. (Test 139) What it says is kept in the
// extension's storage, where every page's script reads it as it changes: a video you play goes into picture-in-
// picture in the same moment, nothing asked. A newer version of this extension on disk (a new build of the skin)
// reloads it, once.
// (Test 344, 2.0) Its button opens a small window in the Menu's colours (popup.html): connected or not, the card's
// Browser button, and the switch that turns it on or off (before, a click on the button turned it on or off). The
// helper sends the Menu's colours with what it says (look); the window reads them, and whether it is connected, from
// the same storage.
const HOST = 'com.monitorsandwidgets.media';
const VERSION = chrome.runtime.getManifest().version;
let port = null;
let wait = 1000;             // before connecting again
let timer = 0;

function brand() {
  const b = ((navigator.userAgentData && navigator.userAgentData.brands) || []).map((x) => x.brand)
    .filter((x) => !/not|chromium/i.test(x));
  return b[0] || '';
}

function newer(a, b) {
  const x = String(a).split('.').map(Number);
  const y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  }
  return false;
}

function card(on) {
  chrome.storage.local.set({ cardOn: !!on });
}

function badge(enabled) {
  chrome.action.setBadgeText({ text: enabled ? 'ON' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ color: enabled ? '#e8b4a0' : '#5a5a5e' });
  if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: enabled ? '#140c0d' : '#ffffff' });
  chrome.action.setTitle({ title: 'Monitors and Widgets: videos to the card (' + (enabled ? 'on' : 'off') + ')' });
}

function connect() {
  if (port) return;
  clearTimeout(timer);
  try {
    port = chrome.runtime.connectNative(HOST);
  } catch (e) {
    port = null;
    card(false);
    chrome.storage.local.set({ connected: false });
    return;
  }
  port.onMessage.addListener((m) => {
    if (!m) return;
    if (typeof m.on === 'boolean') {
      card(m.on);
      chrome.storage.local.set({ connected: true });
      wait = 1000;
    }
    if (m.look && typeof m.look === 'object') chrome.storage.local.set({ look: m.look });
    if (m.version && newer(m.version, VERSION)) {
      chrome.storage.local.get({ reloadedFor: '' }, (r) => {
        if (r.reloadedFor === m.version) return;
        chrome.storage.local.set({ reloadedFor: m.version }, () => chrome.runtime.reload());
      });
    }
  });
  port.onDisconnect.addListener(() => {
    void chrome.runtime.lastError;
    port = null;
    card(false);
    chrome.storage.local.set({ connected: false });
    timer = setTimeout(connect, wait);
    wait = Math.min(wait * 2, 60000);
  });
  // (test 356, 15C) its own shortcut, as the browser gave it (empty: none), with its hello
  const hello = (shortcut) => {
    try {
      if (port) port.postMessage({ listen: 1, hello: VERSION, brand: brand(), shortcut: shortcut || '' });
    } catch (e) { /* (gone: it connects again) */ }
  };
  try {
    chrome.commands.getAll((cmds) => {
      const c = (cmds || []).find((x) => x.name === 'to-card');
      hello(c && c.shortcut);
    });
  } catch (e) {
    hello('');
  }
}

function send(m) {
  if (port) {
    try {
      port.postMessage(m);
      return;
    } catch (e) { /* (gone: once, on its own) */ }
  }
  chrome.runtime.sendNativeMessage(HOST, m, () => void chrome.runtime.lastError);
}

// (test 344) turned on or off from its window: the badge follows, and the helper's log says so
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !c.enabled) return;
  const enabled = c.enabled.newValue !== false;
  badge(enabled);
  if (c.enabled.oldValue !== undefined) send({ note: 'turned ' + (enabled ? 'on' : 'off') + ' from its window' });
});

chrome.runtime.onMessage.addListener((m) => {
  if (!m) return false;
  if (m.wake) connect();
  if (m.failed || m.note || m.pip || m.says) send(m);
  return false;
});

// (test 141) installed or updated: this version's page script goes into the pages already open (an older copy left
// in them stops), so no page needs loading again
function inject() {
  chrome.tabs.query({}, (tabs) => {
    for (const t of tabs || []) {
      if (!t.id || !/^(https?|file):/.test(t.url || '')) continue;
      chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['content.js'] })
        .catch(() => {});
    }
  });
}

// (test 356, 15C: an experiment) the shortcut (Ctrl+Shift+9, global): the tab that plays sound (the active one first)
// sends its playing video to the card, as its own click would. The card presses it for him after Browser
chrome.commands.onCommand.addListener((name) => {
  if (name !== 'to-card') return;
  chrome.tabs.query({ audible: true }, (tabs) => {
    const list = (tabs || []).sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0));
    const t = list[0];
    if (!t || !t.id) {
      send({ note: 'its shortcut was pressed: no tab plays sound' });
      return;
    }
    chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true },
      func: () => { if (window.__mwGo) window.__mwGo(); } })
      .then(() => send({ note: 'its shortcut was pressed: the playing tab asked to send its video' }))
      .catch((e) => send({ note: 'its shortcut was pressed: the tab could not be asked (' + String(e && e.message) + ')' }));
  });
});

chrome.runtime.onInstalled.addListener(() => {
  inject();
  connect();
});
chrome.runtime.onStartup.addListener(connect);
chrome.storage.local.get({ enabled: true }, (r) => badge(r.enabled));
connect();
